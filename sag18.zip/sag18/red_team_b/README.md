# Info

Full name: Joshua Levin

Address
- 12 North Wesley Court, Huntington, NY 11743 (src: https://www.linkedin.com/in/josh-levin-a857b450/)
- New York City Metropolitan Area (src: https://www.linkedin.com/in/josh-levin-a857b450/)
- Long Island, New York (src: https://twitter.com/HEELevin/status/474241094096781313)

Birthday
- 14 August (src: https://twitter.com/HEELevin/status/356457788945338368 + https://twitter.com/HEELevin/status/302043546507157504)

Mom's birthday
- 9 January (src: https://twitter.com/HEELevin/status/156392385818001408)

Job
- Content Producer at The Topps Company (src: https://www.linkedin.com/in/josh-levin-a857b450/)

Prior jobs (src: https://www.linkedin.com/in/josh-levin-a857b450/)
- Assistant Negotioator, ZenithOptimedia - New York, NY
- Staff Writer, YanksGoYard.com, FanSided
- Media	Trainee, ZenithOptimedia - New York, NY
- Associate	Platform Monitor, Major	League Baseball Advanced Media - New York, NY
- WFAN Sports Radio Programming Intern, CBS Radio - New York, NY
- Sports and Assignment	Desk Intern, FOX 5/WNYW - New York, NY 
- News 12 Long Island Sports Intern, Cablevision - Woodbury, NY
- 102.3 WBAB/106.1 WBLI Intern, Cox Media Group Long Island - West Babylon, NY

Favourite food
- cinnamon toast crunch milk and cereal bars (src: https://twitter.com/HEELevin/status/270275069312380929)

Address
- 12 North Wesley Court, Huntington, NY 11743

Phone
- 516-993-6089

Email
- jlevin2118@gmail.com

Instagram
- https://www.instagra/m.com/j11evin (j11evin) (src: https://twitter.com/HEELevin)

Twitter
- https://twitter.com/HEELevin (@HEELevin)
- old: (@jlevin2118)

Linkedin
- https://www.linkedin.com/in/josh-levin-a857b450/

Whitepages
- https://www.whitepages.com/name/Joshua-Levin/Huntington-NY

Datalead
- https://data-lead.com/person/name/Josh+Levin/id/262048077/v/113c9

Medium
- 

Media
- https://twitter.com/HEELevin/status/300038206143991808
- https://twitter.com/HEELevin/status/991321475507458049
- https://twitter.com/HEELevin/status/356082742552834049
- https://twitter.com/HEELevin/status/346621654316748801
- https://www.youtube.com/watch?v=f-ZjbJFg7t8

# Stappenplan

1. In de foto: FANFEST + Haagen-Dazs (src: https://dubbadub.be/s/PnKOILnDsfPvLOdG)
2. Google: fanfest haagen dazs (src: https://www.google.com/search?q=fanfest+haagen+dazs)
3. Klik op "Images"
4. Eerste resultaat: Twitter
5. Open Twitter link (src: https://twitter.com/ordiomongo/status/356098940128608256 -> https://twitter.com/HEELevin/status/356083927791841282)
6. Bekijk tweet
- Posters: @HEELevin + @OrdioMongo
- Mentions: @mikefrancesany + @WFANAudio + @jlevin2118
- Man in foto = Mike Francesa (@MikeFrancesa) / Mike Franceser (@mikefrancesany)
7. Kijk door @HEELevin
8. Vind foto's van hem
9. Vind ongeveer een juist adres
10. Zoek zijn naam op op bv. Linkedin met het adres
11. Vergelijk foto's en mogelijk andere data